using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;
using System.IO;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Validation;

namespace DSLFactory.Candle.SystemModel.Strategies
{
    [Strategy(MyStrategy.StrategyID)]
    public class MyStrategy : StrategyBase, IStrategyCodeGenerator //, IStrategyAddElementInterceptor, IStrategyValidator
    {
        private const string StrategyID = "the strategy unique id"; // or a Guid

        #region Dependency properties
        /// <summary>
        /// Dependency property
        /// </summary>
        public static readonly DependencyProperty<bool> SampleProperty;

        static MyStrategy()
        {            
            SampleProperty = new DependencyProperty<bool>(StrategyID, "name of the property");
            SampleProperty.Category = typeof(MyStrategy).Name; // Category in the properties window
            SampleProperty.DefaultValue = true;                // The default value
        }

        /// <summary>
        /// Contextual dependency properties filter
        /// </summary>
        /// <param name="modelElement"></param>
        /// <returns></returns>
        public override PropertyDescriptorCollection GetCustomProperties(ModelElement modelElement)
        {
            PropertyDescriptorCollection collections = base.GetCustomProperties(modelElement);
     
            if (modelElement is DSLFactory.Candle.SystemModel.Property)
            {
                collections.Add(SampleProperty.Register( (IStrategyProvider)modelElement));
            }

            return collections;
        }
        #endregion

        // Cr�ation du fichier de mapping nhibernate en utilisant le m�canisme de 
        // mappage filtr�e
        public void Execute(IStrategyProvider model)
        {
            try
            {
                if (model == null)
                    throw new ArgumentNullException("model");

                // Main code
                throw new Exception("not implemented");
            }
            catch (Exception ex)
            {
                LogError(ex);
            }
        }

        /// <summary>
        /// Filter element the strategy is applicable on
        /// </summary>
        /// <param name="element"></param>
        /// <returns>true is this strategy is applicable on this element</returns>
        public override bool IsApplicableOn(IStrategyProvider element)
        {
            throw new Exception("not implemented");
            //return element is Property;
        }

        /// <summary>
        /// Exclusive generation
        /// </summary>
        /// <param name="context">Generation context</param>
        /// <param name="currentElement">Implemented element</param>
        /// <param name="generatedFileName">Output file name</param>
        /// <returns>true is the generation is exclusive</returns>
        //public override bool IsModelGenerationExclusive(GenerationContext context, IStrategyProvider currentElement, string generatedFileName)
        //{
        //    if (context.GenerationPass == GenerationPass.CodeGeneration)
        //    {
        //        if (currentElement is ClassImplementation && Utils.StringCompareEquals(Path.GetFileNameWithoutExtension(generatedFileName), currentElement.Name + "Base"))
        //            return true;
        //    }
        //    return base.IsModelGenerationExclusive(context, currentElement, generatedFileName);
        //}

        #region IStrategyAddElementInterceptor
        /// <summary>
        /// Called when an element is added to the model
        /// </summary>
        /// <param name="owner"></param>
        /// <param name="e"></param>
        //public void OnElementAdded(IStrategyProvider owner, StrategyElementElementAddedEventArgs e)
        //{
        //}

        /// <summary>
        /// Can return a wizard to display when an element is added to the model
        /// </summary>
        /// <remarks>
        /// This method is called before the OnElementAdded event
        /// </remarks>
        /// <param name="model"></param>
        /// <returns></returns>
        //public IStrategyWizard GetWizard(ModelElement model)
        //{
        //    return null;
        //}
        #endregion

        #region IStrategyValidator Members

        /// <summary>
        /// Validate an element
        /// </summary>
        /// <param name="element"></param>
        /// <param name="logInfo"></param>
        //public void Validate(ModelElement element, ValidationContext logInfo)
        //{
        //}

        #endregion
    }
}
